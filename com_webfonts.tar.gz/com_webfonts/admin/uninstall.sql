DROP TABLE IF EXISTS `#__webfonts`;
DROP TABLE IF EXISTS `#__webfonts_vendor`;
DROP TABLE IF EXISTS `#__webfonts_fontscom`;
DROP TABLE IF EXISTS `#__webfonts_google`;